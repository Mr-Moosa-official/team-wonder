const tintColorLight = '#E76F51';

export default {
  light: {
    text: '#2A2A2A',
    background: '#FFFCF7',
    backgroundSecondary: '#F9F4EA',
    tint: tintColorLight,
    tabIconDefault: '#8D8D8D',
    tabIconSelected: tintColorLight,
    primary: '#E76F51',
    secondary: '#F4A261',
    accent: '#2A9D8F',
    neutral: '#8D8D8D',
    neutralLight: '#E5E5E5',
    success: '#2A9D8F',
    warning: '#F4A261',
    error: '#E63946',
    card: '#FFFFFF',
    cardBorder: '#F1EBE0',
  },
};