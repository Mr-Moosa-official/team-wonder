import React, { useState } from 'react';
import { View, ScrollView, StyleSheet, Text } from 'react-native';
import { RefreshControl } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import StoryCard from '../../components/StoryCard';
import CategoryFilter from '../../components/CategoryFilter';
import { categories, recipients, featuredStory } from '../../utils/mockData';
import Colors from '../../constants/Colors';
import Layout from '../../constants/Layout';

export default function HomeScreen() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [refreshing, setRefreshing] = useState(false);

  const filteredRecipients = selectedCategory === 'All'
    ? recipients
    : recipients.filter(recipient => recipient.category === selectedCategory);

  const onRefresh = () => {
    setRefreshing(true);
    // Simulate a network request
    setTimeout(() => {
      setRefreshing(false);
    }, 1500);
  };

  return (
    <SafeAreaView style={styles.container} edges={['bottom']}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContainer}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.light.primary}
          />
        }
      >
        <View style={styles.headerContainer}>
          <Text style={styles.tagline}>
            Small Amounts. Big Change.
          </Text>
        </View>

        <StoryCard recipient={featuredStory} index={0} featured />
        
        <Text style={styles.sectionTitle}>Causes that need your help</Text>
        
        <CategoryFilter
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />
        
        <View style={styles.storiesContainer}>
          {filteredRecipients.map((recipient, index) => (
            <StoryCard 
              key={recipient.id} 
              recipient={recipient} 
              index={index + 1} 
            />
          ))}
        </View>
        
        <View style={styles.inspirationContainer}>
          <Text style={styles.inspirationText}>
            "Never believe that a few caring people can't change the world. 
            For, indeed, that's all who ever have."
          </Text>
          <Text style={styles.quoteAuthor}>— Margaret Mead</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  scrollContainer: {
    paddingHorizontal: Layout.spacing.md,
    paddingTop: Layout.spacing.md,
    paddingBottom: Layout.spacing.xl,
  },
  headerContainer: {
    marginBottom: Layout.spacing.md,
  },
  tagline: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.light.neutral,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: Colors.light.text,
    marginTop: Layout.spacing.lg,
  },
  storiesContainer: {
    marginTop: Layout.spacing.md,
  },
  inspirationContainer: {
    marginTop: Layout.spacing.xl,
    padding: Layout.spacing.lg,
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: Layout.borderRadius.lg,
    alignItems: 'center',
  },
  inspirationText: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: Colors.light.text,
    textAlign: 'center',
    fontStyle: 'italic',
    lineHeight: 24,
  },
  quoteAuthor: {
    fontFamily: 'Inter-Medium',
    fontSize: 14,
    color: Colors.light.neutral,
    marginTop: Layout.spacing.md,
  },
});