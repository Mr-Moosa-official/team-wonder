export interface Recipient {
  id: string;
  name: string;
  age: number;
  location: string;
  imageUrl: string;
  story: string;
  quote: string;
  category: 'Education' | 'Health' | 'Food' | 'Housing' | 'Emergency';
  goal: number;
  raised: number;
  verifiedBy: string;
  documents?: string[];
  updates?: Update[];
}

export interface Update {
  id: string;
  date: string;
  message: string;
  imageUrl?: string;
}

export interface Donation {
  id: string;
  recipientId: string;
  amount: number;
  date: string;
  message?: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
}

export const recipients: Recipient[] = [
  {
    id: '1',
    name: 'Aanya Sharma',
    age: 9,
    location: 'Mumbai, Maharashtra',
    imageUrl: 'https://images.pexels.com/photos/5560485/pexels-photo-5560485.jpeg',
    story: 'Aanya lives with her grandmother after losing her parents. She\'s bright and wants to be a doctor, but her grandmother cannot afford the school fees for the next semester.',
    quote: "I want to help sick people like the doctors who tried to save my parents.",
    category: 'Education',
    goal: 5000,
    raised: 2750,
    verifiedBy: 'Educate India NGO',
    updates: [
      {
        id: 'u1',
        date: '2025-01-15',
        message: 'I got admitted to school! Thank you for your help.',
        imageUrl: 'https://images.pexels.com/photos/8535208/pexels-photo-8535208.jpeg'
      }
    ]
  },
  {
    id: '2',
    name: 'Ravi Kumar',
    age: 35,
    location: 'Bangalore, Karnataka',
    imageUrl: 'https://images.pexels.com/photos/2774546/pexels-photo-2774546.jpeg',
    story: 'Ravi is a father of two who lost his job during the pandemic. His wife has been diagnosed with a chronic illness and needs medication. He\'s looking for work but needs help with immediate medical expenses.',
    quote: "My children need their mother. Your help means everything to us.",
    category: 'Health',
    goal: 15000,
    raised: 4200,
    verifiedBy: 'MedAssist Foundation'
  },
  {
    id: '3',
    name: 'Maya Patel',
    age: 68,
    location: 'Ahmedabad, Gujarat',
    imageUrl: 'https://images.pexels.com/photos/3768183/pexels-photo-3768183.jpeg',
    story: 'Maya is an elderly woman who lost her home in a fire. She has no family and lived alone, surviving on meager savings. She needs help to secure basic housing and necessities.',
    quote: "At my age, starting over seems impossible. But I\'m not giving up.",
    category: 'Housing',
    goal: 25000,
    raised: 18000,
    verifiedBy: 'ShelterFirst Initiative'
  },
  {
    id: '4',
    name: 'Arjun & Divya',
    age: 6,
    location: 'Delhi, NCR',
    imageUrl: 'https://images.pexels.com/photos/1001914/pexels-photo-1001914.jpeg',
    story: 'These siblings lost their parents in a tragic accident. Their aunt has taken them in but struggles to provide enough food for them alongside her own children.',
    quote: "We miss our parents, but aunt says good people are helping us now.",
    category: 'Food',
    goal: 7500,
    raised: 3200,
    verifiedBy: 'Children First Foundation',
    updates: [
      {
        id: 'u1',
        date: '2025-02-10',
        message: 'The children now have regular meals and are attending school. Thank you!',
        imageUrl: 'https://images.pexels.com/photos/8494573/pexels-photo-8494573.jpeg'
      }
    ]
  },
  {
    id: '5',
    name: 'Kavita Reddy',
    age: 28,
    location: 'Hyderabad, Telangana',
    imageUrl: 'https://images.pexels.com/photos/6647037/pexels-photo-6647037.jpeg',
    story: 'Kavita, a single mother of a 3-year-old, was recently diagnosed with a treatable form of cancer. She needs funds for treatment so she can continue to care for her daughter.',
    quote: "I have to survive for my daughter. She has no one else.",
    category: 'Health',
    goal: 50000,
    raised: 22400,
    verifiedBy: 'Cancer Care India'
  },
  {
    id: '6',
    name: 'Rahul Mehra',
    age: 22,
    location: 'Pune, Maharashtra',
    imageUrl: 'https://images.pexels.com/photos/2531738/pexels-photo-2531738.jpeg',
    story: 'Rahul comes from a farming family that lost everything in the floods. He\'s the first in his family to reach college but might have to drop out due to financial constraints.',
    quote: "Education is my only path out of poverty for my entire family.",
    category: 'Education',
    goal: 18000,
    raised: 9600,
    verifiedBy: 'Rural Education Trust'
  }
];

export const featuredStory = recipients[3]; // Arjun & Divya as the featured story

export const userDonations: Donation[] = [
  {
    id: 'd1',
    recipientId: '1',
    amount: 500,
    date: '2025-02-01',
    message: 'Stay strong and keep studying!'
  },
  {
    id: 'd2', 
    recipientId: '4',
    amount: 1000,
    date: '2025-01-28'
  }
];

export const userBadges: Badge[] = [
  {
    id: 'b1',
    name: 'First Hope',
    description: 'Made your first donation',
    icon: 'heart',
    earned: true
  },
  {
    id: 'b2',
    name: 'Education Champion',
    description: 'Donated to 3 education causes',
    icon: 'book',
    earned: true
  },
  {
    id: 'b3',
    name: 'Consistent Giver',
    description: 'Donated for 3 consecutive months',
    icon: 'calendar',
    earned: false
  },
  {
    id: 'b4',
    name: 'Community Builder',
    description: 'Referred 5 friends who donated',
    icon: 'users',
    earned: false
  }
];

export const categories = [
  'All',
  'Education',
  'Health',
  'Food',
  'Housing',
  'Emergency'
];